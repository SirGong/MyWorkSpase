create
    definer = root@localhost procedure proc_7_2(OUT a int)
begin 
   select floor(rand()*10+1) into a;
end;

