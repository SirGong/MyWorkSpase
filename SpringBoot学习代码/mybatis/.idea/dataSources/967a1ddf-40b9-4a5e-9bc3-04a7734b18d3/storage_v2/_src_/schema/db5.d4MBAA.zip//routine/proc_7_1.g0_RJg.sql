create
    definer = root@localhost procedure proc_7_1(IN a int, IN b int)
begin
select a+b;
end;

