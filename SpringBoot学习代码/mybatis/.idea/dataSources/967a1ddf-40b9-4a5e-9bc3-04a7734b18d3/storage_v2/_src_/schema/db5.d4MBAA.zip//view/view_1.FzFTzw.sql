create view view_1 as
select `db5`.`userinfo`.`userid`      AS `userid`,
       `db5`.`userinfo`.`userName`    AS `userName`,
       `db5`.`userinfo`.`userSex`     AS `userSex`,
       `db5`.`userinfo`.`userAge`     AS `userAge`,
       `db5`.`userinfo`.`userAddress` AS `userAddress`,
       `db5`.`userinfo`.`userpass`    AS `userpass`,
       `db5`.`userinfo`.`userstate`   AS `userstate`
from `db5`.`userinfo`;

