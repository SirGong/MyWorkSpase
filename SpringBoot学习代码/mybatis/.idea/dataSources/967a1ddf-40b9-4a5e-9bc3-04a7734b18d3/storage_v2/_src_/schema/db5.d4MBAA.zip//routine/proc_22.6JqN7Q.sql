create
    definer = root@localhost procedure proc_22()
BEGIN
    #定义三个变量
    DECLARE a int;
    DECLARE b int;
    DECLARE c int;
    #给变量赋值操作
    set a=1;
    set b=2;
    set c=a+b;
END;

