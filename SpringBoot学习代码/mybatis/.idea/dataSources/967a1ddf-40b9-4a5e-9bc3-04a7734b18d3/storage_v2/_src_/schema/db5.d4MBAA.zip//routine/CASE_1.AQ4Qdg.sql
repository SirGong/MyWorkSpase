create
    definer = root@localhost procedure CASE_1()
BEGIN
    declare i INT;
    select FLOOR(RAND()*10+1) INTO i;
    CASE
	WHEN i<3 THEN
	SELECT 'A';
	WHEN i<5 THEN
	SELECT 'B';
	WHEN i<8 THEN
	SELECT 'C';
	ELSE
	SELECT 'D'; 
     END CASE;
END;

