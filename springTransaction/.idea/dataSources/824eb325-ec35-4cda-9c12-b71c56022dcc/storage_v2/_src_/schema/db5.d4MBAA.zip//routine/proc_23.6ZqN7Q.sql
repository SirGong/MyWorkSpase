create
    definer = root@localhost procedure proc_23()
BEGIN
    #定义三个变量
    DECLARE a,b int;
    declare c int default 1;
    #两种赋值方式
    set a=3;
    select Floor(rand()*10) into b;
    set c= a+b+c;
    select c;
END;

