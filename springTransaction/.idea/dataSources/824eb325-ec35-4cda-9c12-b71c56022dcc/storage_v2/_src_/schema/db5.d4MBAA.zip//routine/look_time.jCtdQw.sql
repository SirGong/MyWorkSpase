create
    definer = root@localhost procedure look_time()
BEGIN
    DECLARE years,months,days,weeks,hours,minutes,seconds int;
    declare str varchar(50);
    select year(now()) into years;
    select month(now()) into months;
    select dayofmonth(now()) into days;
    select hour(now()) into hours;
    select minute(now()) into minutes;
    select second(now()) into seconds;
    select dayofweek(now())-1 into weeks;
    select concat(cast(years as char),'年',CAST(months AS CHAR),'月',CAST(days AS CHAR),'日',
    ' 星期',CAST(weeks AS CHAR),CAST(yhours AS CHAR),': ',CAST(minutes AS CHAR),':',CAST(seconds AS CHAR)) into str;
    select str;
    
    
    
END;

