create
    definer = root@localhost procedure youbiao()
begin
declare id1 int;
declare name1 varchar(10);
declare sex1 char(1);
declare age1 int;
declare address1 varchar(10);
declare state1 int;
#创建游标：
declare cursor_1 cursor for select * from uesrinfo;
#打开游标:
open cursor_1;
#提取游标
fetch cursor_1 into id1,name1,sex1,age1,address1,state1;
select id1,name1,sex1,age1,address1,state1;
#关闭游标
close cursor_1;
end;

